"""
app.py
Streamlit interactive dashboard for the Semantic Stock Analyzer.

Run:
    streamlit run app.py
"""

import os
import sys
import time
import logging
import threading
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta

# ── Page Config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Semantic Stock Analyzer",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Dark theme CSS ─────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main background */
    .stApp { background-color: #0d1117; color: #e6edf3; }
    .block-container { padding-top: 1.5rem; padding-bottom: 1rem; }

    /* Metric cards */
    [data-testid="metric-container"] {
        background: #161b22;
        border: 1px solid #30363d;
        border-radius: 10px;
        padding: 14px 18px;
    }
    [data-testid="metric-container"] label { color: #8b949e !important; font-size: 0.8rem; }
    [data-testid="metric-container"] [data-testid="stMetricValue"] { color: #e6edf3; font-size: 1.6rem; }
    [data-testid="metric-container"] [data-testid="stMetricDelta"] { font-size: 0.85rem; }

    /* Sidebar */
    [data-testid="stSidebar"] { background-color: #161b22; border-right: 1px solid #30363d; }
    [data-testid="stSidebar"] * { color: #e6edf3 !important; }

    /* Headers */
    h1, h2, h3 { color: #e6edf3 !important; }
    .dashboard-title {
        font-size: 2rem; font-weight: 800;
        background: linear-gradient(90deg, #58a6ff, #3fb950);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        margin-bottom: 0;
    }
    .subtitle { color: #8b949e; font-size: 0.9rem; margin-top: -6px; margin-bottom: 1.2rem; }

    /* Pill badges */
    .badge {
        display: inline-block; padding: 2px 10px;
        border-radius: 20px; font-size: 0.78rem; font-weight: 600;
        margin: 2px;
    }
    .badge-bullish { background: #1a3a2a; color: #3fb950; border: 1px solid #3fb950; }
    .badge-bearish { background: #3a1a1a; color: #f85149; border: 1px solid #f85149; }
    .badge-neutral { background: #1a1f2a; color: #8b949e; border: 1px solid #30363d; }

    /* Section cards */
    .section-card {
        background: #161b22; border: 1px solid #30363d;
        border-radius: 12px; padding: 18px; margin-bottom: 12px;
    }

    /* Ticker chips */
    .ticker-chip {
        display: inline-block; padding: 2px 8px;
        border-radius: 4px; font-size: 0.72rem; font-weight: 700;
        background: #21262d; color: #58a6ff;
        border: 1px solid #30363d; margin: 1px;
    }

    /* Status indicator */
    .status-live { color: #3fb950; }
    .status-demo { color: #e3b341; }

    /* Table */
    .dataframe { background: #161b22 !important; color: #e6edf3 !important; }

    /* Hide Streamlit branding */
    #MainMenu { visibility: hidden; }
    footer { visibility: hidden; }

    /* Scrollable article table */
    .article-row {
        background: #161b22; border: 1px solid #30363d;
        border-radius: 8px; padding: 10px 14px; margin-bottom: 6px;
    }
    .article-title { font-weight: 600; font-size: 0.88rem; color: #e6edf3; }
    .article-meta { font-size: 0.76rem; color: #8b949e; margin-top: 2px; }
</style>
""", unsafe_allow_html=True)


# ── Color constants ────────────────────────────────────────────────────────────
PALETTE = {
    "bullish": "#3fb950", "bearish": "#f85149", "neutral": "#8b949e",
    "accent": "#58a6ff", "warning": "#e3b341", "bg": "#0d1117",
    "panel": "#161b22", "border": "#30363d", "text": "#e6edf3",
}

SECTOR_COLORS = {
    "Information Technology": "#58a6ff", "Health Care": "#3fb950",
    "Financials": "#e3b341", "Consumer Discretionary": "#ff7b72",
    "Communication Services": "#bc8cff", "Industrials": "#79c0ff",
    "Consumer Staples": "#56d364", "Energy": "#f78166",
    "Utilities": "#ffa657", "Real Estate": "#d2a8ff",
    "Materials": "#7ee787", "General Market": "#8b949e",
}


# ── Session state ─────────────────────────────────────────────────────────────
def _init_state():
    defaults = {
        "df": None,
        "last_run": None,
        "running": False,
        "run_log": [],
        "demo_mode": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()


# ── Demo data generator ───────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def _generate_demo_df(seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n = 150

    sectors = list(SECTOR_COLORS.keys())
    sentiments = ["bullish", "neutral", "bearish"]
    sources = ["Reuters", "Bloomberg", "CNBC", "MarketWatch",
               "Yahoo Finance", "Seeking Alpha", "Financial Times"]
    magnitudes = ["high", "medium", "low"]

    titles = [
        "NVIDIA forecasts record AI chip sales amid surging demand",
        "Fed signals rate pause as inflation cools further",
        "Energy stocks surge after OPEC+ extends production cuts",
        "JPMorgan beats Q3 earnings, raises full-year guidance",
        "Tesla delivers record EVs but faces margin compression",
        "Healthcare sector navigates regulatory headwinds",
        "Retail sales beat expectations, consumer resilience intact",
        "Industrial output slows as global trade tensions mount",
        "Utility stocks attractive as bond yields stabilize",
        "Real estate shows green shoots amid rate plateau",
        "Semiconductor shortage eases, chip stocks rally broadly",
        "Bank of Japan policy shift rattles financial markets",
        "Amazon Web Services revenue accelerates on AI workloads",
        "Oil prices retreat on weaker-than-expected China data",
        "Biotech index surges after FDA approves key drug",
        "Microsoft Azure growth beats cloud rivals for fourth quarter",
        "Apple unveils next-gen iPhone with AI integration suite",
        "Goldman Sachs upgrades S&P 500 target on earnings momentum",
        "EV battery cost declines accelerate industry adoption",
        "Copper prices hit multi-year high on green energy demand",
    ] * 8

    sentiment_arr = rng.choice(sentiments, n, p=[0.42, 0.28, 0.30])
    scores = np.where(
        sentiment_arr == "bullish", rng.uniform(0.15, 0.95, n),
        np.where(sentiment_arr == "bearish", -rng.uniform(0.15, 0.95, n),
                 rng.uniform(-0.12, 0.12, n))
    )

    sector_arr = rng.choice(sectors, n)
    impact = scores * rng.uniform(1.2, 3.5, n)  # ±1–4%

    df = pd.DataFrame({
        "article_id": [f"demo_{i:04d}" for i in range(n)],
        "title": rng.choice(titles, n),
        "source": rng.choice(sources, n),
        "primary_sector": sector_arr,
        "sentiment": sentiment_arr,
        "sentiment_score": scores.round(4),
        "confidence": rng.uniform(0.45, 0.95, n).round(3),
        "impact_magnitude": rng.choice(magnitudes, n, p=[0.22, 0.48, 0.30]),
        "predicted_price_impact_pct": impact.round(3),
        "sector_relevance": rng.uniform(0.3, 1.0, n).round(3),
        "key_drivers": ["AI demand | cloud | earnings"] * n,
        "analysis_method": rng.choice(["gemini", "lexicon"], n, p=[0.35, 0.65]),
        "published": [
            datetime.now() - timedelta(hours=int(h))
            for h in rng.integers(0, 48, n)
        ],
        "url": [f"https://example.com/article/{i}" for i in range(n)],
    })
    return df


# ── Pipeline runner ───────────────────────────────────────────────────────────
def run_pipeline_async(gemini_key: str, max_articles: int, days_back: int):
    """Run the pipeline in a background thread and store results in session state."""
    st.session_state["running"] = True
    st.session_state["run_log"] = []

    def _run():
        try:
            sys.path.insert(0, os.path.dirname(__file__))

            from news_scraper import FinancialNewsScraper
            from sector_mapper import SectorMapper
            from sentiment_analyzer import SentimentAnalyzer
            from ml_models import EnsemblePredictor

            log = st.session_state["run_log"]

            log.append("🔍 Scraping financial news...")
            scraper = FinancialNewsScraper(
                max_articles_per_source=max_articles // 8,
                days_back=days_back,
            )
            df = scraper.fetch_all(include_full_text=False)
            log.append(f"✅ Fetched {len(df)} articles")

            if df.empty:
                log.append("❌ No articles fetched. Try demo mode.")
                st.session_state["running"] = False
                return

            log.append("🗂️ Mapping articles to S&P 500 sectors...")
            mapper = SectorMapper()
            df = mapper.map_dataframe(df)
            log.append(f"✅ Sectors mapped")

            log.append("🧠 Running sentiment analysis...")
            analyzer = SentimentAnalyzer(gemini_api_key=gemini_key)
            df = analyzer.analyze_dataframe(df)
            log.append(f"✅ Sentiment analysis complete")

            log.append("📊 Running ML ensemble predictions...")
            predictor = EnsemblePredictor()
            if not predictor.load():
                log.append("  Training models (first run)...")
                predictor.train()
            df = predictor.predict_dataframe(df)
            log.append("✅ Predictions complete")

            st.session_state["df"] = df
            st.session_state["last_run"] = datetime.now()
            st.session_state["demo_mode"] = False
            log.append("🎉 Pipeline complete!")

        except Exception as e:
            st.session_state["run_log"].append(f"❌ Error: {e}")
        finally:
            st.session_state["running"] = False

    t = threading.Thread(target=_run, daemon=True)
    t.start()


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚡ Stock Analyzer")
    st.markdown("---")

    st.markdown("### 🔧 Pipeline Settings")
    gemini_key = st.text_input(
        "Gemini API Key", type="password",
        value=os.getenv("GEMINI_API_KEY", ""),
        help="Optional. Get a free key at aistudio.google.com",
    )
    max_articles = st.slider("Max Articles", 20, 200, 80, step=20)
    days_back = st.slider("Days Back", 1, 7, 2)

    st.markdown("---")

    col1, col2 = st.columns(2)
    with col1:
        live_btn = st.button("▶ Run Live", use_container_width=True,
                             disabled=st.session_state["running"])
    with col2:
        demo_btn = st.button("🧪 Demo", use_container_width=True,
                             disabled=st.session_state["running"])

    if live_btn:
        run_pipeline_async(gemini_key, max_articles, days_back)

    if demo_btn:
        st.session_state["df"] = _generate_demo_df()
        st.session_state["last_run"] = datetime.now()
        st.session_state["demo_mode"] = True
        st.session_state["run_log"] = ["🧪 Demo data loaded — 150 synthetic articles"]

    if st.session_state["running"]:
        st.markdown("### 🔄 Progress")
        for msg in st.session_state["run_log"]:
            st.markdown(f"<small>{msg}</small>", unsafe_allow_html=True)
        st.spinner("Running...")

    if st.session_state["run_log"] and not st.session_state["running"]:
        with st.expander("📋 Last run log", expanded=False):
            for msg in st.session_state["run_log"]:
                st.markdown(f"<small>{msg}</small>", unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 📥 Export")
    if st.session_state["df"] is not None:
        df_export = st.session_state["df"]
        csv = df_export.to_csv(index=False).encode()
        st.download_button("⬇ Download CSV", csv, "stock_analysis.csv", "text/csv",
                           use_container_width=True)

    st.markdown("---")
    st.markdown(
        "<small style='color:#8b949e'>Built with ❤️ · Streamlit + Plotly<br>"
        "Sentiment: Gemini / Lexicon fallback<br>"
        "ML: AdaBoost + GBM + PyTorch NN</small>",
        unsafe_allow_html=True,
    )


# ── Main content ──────────────────────────────────────────────────────────────
st.markdown('<div class="dashboard-title">⚡ Semantic Stock Signal Dashboard</div>', unsafe_allow_html=True)

if st.session_state["last_run"]:
    mode_badge = '🧪 DEMO MODE' if st.session_state.get("demo_mode") else '🟢 LIVE'
    st.markdown(
        f'<div class="subtitle">{mode_badge} &nbsp;·&nbsp; '
        f'Last updated: {st.session_state["last_run"].strftime("%Y-%m-%d %H:%M:%S")}'
        f' &nbsp;·&nbsp; S&P 500 Sector Intelligence</div>',
        unsafe_allow_html=True,
    )
else:
    st.markdown(
        '<div class="subtitle">Click <b>▶ Run Live</b> to fetch real news, or <b>🧪 Demo</b> to preview instantly.</div>',
        unsafe_allow_html=True,
    )

# ── No data yet ───────────────────────────────────────────────────────────────
if st.session_state["df"] is None:
    st.info("👆 Hit **🧪 Demo** in the sidebar to load sample data instantly, or **▶ Run Live** to analyze today's real financial news.")
    
    # Feature preview
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("""
        <div class="section-card">
        <h4>📰 Live News Scraping</h4>
        <p style="color:#8b949e;font-size:0.85rem">
        Pulls from Reuters, Bloomberg, CNBC, MarketWatch, Yahoo Finance, 
        Seeking Alpha & FT via RSS + direct HTML scraping.
        </p>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown("""
        <div class="section-card">
        <h4>🧠 AI Sentiment Analysis</h4>
        <p style="color:#8b949e;font-size:0.85rem">
        Google Gemini 1.5 Flash for deep equity research analysis.
        Falls back to financial lexicon (no API key needed).
        </p>
        </div>
        """, unsafe_allow_html=True)
    with c3:
        st.markdown("""
        <div class="section-card">
        <h4>📊 ML Price Prediction</h4>
        <p style="color:#8b949e;font-size:0.85rem">
        Ensemble of AdaBoost, Gradient Boosting & PyTorch Neural Net
        predicts sector-level price impact signals.
        </p>
        </div>
        """, unsafe_allow_html=True)
    st.stop()


# ── Load data ─────────────────────────────────────────────────────────────────
df = st.session_state["df"].copy()

# Fill missing cols defensively
for col, default in [
    ("sentiment", "neutral"), ("sentiment_score", 0.0),
    ("confidence", 0.5), ("predicted_price_impact_pct", 0.0),
    ("primary_sector", "General Market"), ("source", "Unknown"),
    ("impact_magnitude", "medium"),
]:
    if col not in df.columns:
        df[col] = default

df["published"] = pd.to_datetime(df.get("published", pd.NaT), errors="coerce")


# ── Filters ───────────────────────────────────────────────────────────────────
st.markdown("### 🔎 Filters")
fc1, fc2, fc3, fc4 = st.columns([2, 2, 2, 1])
with fc1:
    all_sectors = sorted(df["primary_sector"].dropna().unique().tolist())
    sel_sectors = st.multiselect("Sectors", all_sectors, default=all_sectors, label_visibility="collapsed")
with fc2:
    sel_sentiments = st.multiselect("Sentiment", ["bullish", "neutral", "bearish"],
                                    default=["bullish", "neutral", "bearish"],
                                    label_visibility="collapsed")
with fc3:
    all_sources = sorted(df["source"].dropna().unique().tolist())
    sel_sources = st.multiselect("Sources", all_sources, default=all_sources,
                                 label_visibility="collapsed")
with fc4:
    st.markdown("<br>", unsafe_allow_html=True)
    reset = st.button("↺ Reset", use_container_width=True)
    if reset:
        sel_sectors = all_sectors
        sel_sentiments = ["bullish", "neutral", "bearish"]
        sel_sources = all_sources

mask = (
    df["primary_sector"].isin(sel_sectors) &
    df["sentiment"].isin(sel_sentiments) &
    df["source"].isin(sel_sources)
)
fdf = df[mask].copy()

if fdf.empty:
    st.warning("No articles match current filters.")
    st.stop()


# ── KPI metrics ───────────────────────────────────────────────────────────────
st.markdown("---")
m1, m2, m3, m4, m5, m6 = st.columns(6)
n_total = len(fdf)
n_bull = (fdf["sentiment"] == "bullish").sum()
n_bear = (fdf["sentiment"] == "bearish").sum()
n_neut = n_total - n_bull - n_bear
avg_impact = fdf["predicted_price_impact_pct"].mean()
avg_conf = fdf["confidence"].mean()
top_sector = (
    fdf.groupby("primary_sector")["predicted_price_impact_pct"]
    .mean().abs().idxmax()
)

m1.metric("📰 Articles", n_total)
m2.metric("🟢 Bullish", n_bull, delta=f"{n_bull/n_total:.0%}")
m3.metric("🔴 Bearish", n_bear, delta=f"{n_bear/n_total:.0%}", delta_color="inverse")
m4.metric("📊 Avg Impact", f"{avg_impact:+.2f}%",
          delta="bullish" if avg_impact > 0 else "bearish",
          delta_color="normal" if avg_impact > 0 else "inverse")
m5.metric("🎯 Avg Confidence", f"{avg_conf:.0%}")
m6.metric("🏆 Top Sector", top_sector.replace(" ", "\n")[:18])


# ── Charts row 1 ──────────────────────────────────────────────────────────────
st.markdown("---")
ch1, ch2 = st.columns([3, 2])

# Sector impact bar chart
with ch1:
    sector_summary = (
        fdf.groupby("primary_sector")
        .agg(
            avg_impact=("predicted_price_impact_pct", "mean"),
            avg_conf=("confidence", "mean"),
            count=("title", "count"),
            bullish=("sentiment", lambda x: (x == "bullish").sum()),
            bearish=("sentiment", lambda x: (x == "bearish").sum()),
        )
        .reset_index()
        .sort_values("avg_impact")
    )
    sector_summary["color"] = sector_summary["avg_impact"].apply(
        lambda x: PALETTE["bullish"] if x >= 0 else PALETTE["bearish"]
    )
    sector_summary["label"] = sector_summary["avg_impact"].apply(lambda x: f"{x:+.2f}%")

    fig_bar = go.Figure(go.Bar(
        x=sector_summary["avg_impact"],
        y=sector_summary["primary_sector"],
        orientation="h",
        marker_color=sector_summary["color"],
        text=sector_summary["label"],
        textposition="outside",
        hovertemplate=(
            "<b>%{y}</b><br>"
            "Avg Impact: %{x:+.2f}%<br>"
            "Articles: %{customdata[0]}<br>"
            "Confidence: %{customdata[1]:.0%}<extra></extra>"
        ),
        customdata=sector_summary[["count", "avg_conf"]].values,
        error_x=dict(
            type="data",
            array=[(1 - c) * 1.5 for c in sector_summary["avg_conf"]],
            color=PALETTE["border"], thickness=1.5, width=4,
        ),
    ))
    fig_bar.update_layout(
        title="📈 Predicted Price Impact by Sector",
        paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
        font_color=PALETTE["text"], height=380,
        xaxis=dict(gridcolor=PALETTE["border"], zeroline=True,
                   zerolinecolor=PALETTE["border"], zerolinewidth=2),
        yaxis=dict(gridcolor=PALETTE["border"]),
        margin=dict(l=10, r=60, t=40, b=10),
        showlegend=False,
    )
    st.plotly_chart(fig_bar, use_container_width=True)

# Sentiment donut
with ch2:
    sent_counts = fdf["sentiment"].value_counts().reset_index()
    sent_counts.columns = ["sentiment", "count"]
    color_map = {"bullish": PALETTE["bullish"], "bearish": PALETTE["bearish"],
                 "neutral": PALETTE["neutral"]}

    fig_pie = go.Figure(go.Pie(
        labels=sent_counts["sentiment"],
        values=sent_counts["count"],
        hole=0.6,
        marker_colors=[color_map.get(s, PALETTE["neutral"]) for s in sent_counts["sentiment"]],
        textinfo="label+percent",
        textfont_size=11,
        hovertemplate="<b>%{label}</b><br>%{value} articles (%{percent})<extra></extra>",
    ))
    fig_pie.add_annotation(
        text=f"<b>{n_total}</b><br><span style='font-size:11px'>articles</span>",
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=18, color=PALETTE["text"]),
    )
    fig_pie.update_layout(
        title="🧭 Sentiment Distribution",
        paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
        font_color=PALETTE["text"], height=380,
        margin=dict(l=10, r=10, t=40, b=10),
        legend=dict(bgcolor=PALETTE["panel"], bordercolor=PALETTE["border"]),
        showlegend=True,
    )
    st.plotly_chart(fig_pie, use_container_width=True)


# ── Charts row 2 ──────────────────────────────────────────────────────────────
ch3, ch4 = st.columns([2, 3])

# Source distribution
with ch3:
    source_counts = fdf["source"].value_counts().reset_index()
    source_counts.columns = ["source", "count"]

    fig_src = px.bar(
        source_counts, x="count", y="source", orientation="h",
        color="count", color_continuous_scale=["#21262d", PALETTE["accent"]],
        labels={"count": "Articles", "source": ""},
        title="📡 Articles by Source",
    )
    fig_src.update_layout(
        paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
        font_color=PALETTE["text"], height=320,
        coloraxis_showscale=False,
        xaxis=dict(gridcolor=PALETTE["border"]),
        yaxis=dict(gridcolor=PALETTE["border"]),
        margin=dict(l=10, r=10, t=40, b=10),
    )
    st.plotly_chart(fig_src, use_container_width=True)

# Scatter: sentiment vs impact
with ch4:
    scatter_df = fdf.copy()
    scatter_df["size"] = (scatter_df["confidence"] * 20 + 5).clip(5, 25)
    scatter_df["color"] = scatter_df["primary_sector"].map(SECTOR_COLORS).fillna(PALETTE["neutral"])

    fig_scatter = go.Figure()
    for sector in scatter_df["primary_sector"].unique():
        sub = scatter_df[scatter_df["primary_sector"] == sector]
        fig_scatter.add_trace(go.Scatter(
            x=sub["sentiment_score"], y=sub["predicted_price_impact_pct"],
            mode="markers",
            name=sector,
            marker=dict(
                color=SECTOR_COLORS.get(sector, PALETTE["neutral"]),
                size=sub["size"], opacity=0.75,
                line=dict(width=0.5, color=PALETTE["border"]),
            ),
            hovertemplate=(
                "<b>%{customdata[0]}</b><br>"
                "Sentiment: %{x:.3f}<br>"
                "Impact: %{y:+.2f}%<br>"
                "Source: %{customdata[1]}<br>"
                "Confidence: %{customdata[2]:.0%}<extra></extra>"
            ),
            customdata=sub[["title", "source", "confidence"]].values,
        ))

    # Trend line
    try:
        x = scatter_df["sentiment_score"].fillna(0).values
        y = scatter_df["predicted_price_impact_pct"].fillna(0).values
        if len(x) > 5:
            z = np.polyfit(x, y, 1)
            p = np.poly1d(z)
            xl = np.linspace(x.min(), x.max(), 100)
            fig_scatter.add_trace(go.Scatter(
                x=xl, y=p(xl), mode="lines",
                line=dict(color=PALETTE["accent"], width=2, dash="dot"),
                name="Trend", showlegend=False,
            ))
    except Exception:
        pass

    fig_scatter.add_hline(y=0, line_color=PALETTE["border"], line_width=1)
    fig_scatter.add_vline(x=0, line_color=PALETTE["border"], line_width=1)
    fig_scatter.update_layout(
        title="🎯 Sentiment Score vs Predicted Impact",
        paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
        font_color=PALETTE["text"], height=320,
        xaxis=dict(title="Sentiment Score", gridcolor=PALETTE["border"]),
        yaxis=dict(title="Predicted Impact (%)", gridcolor=PALETTE["border"]),
        legend=dict(bgcolor=PALETTE["panel"], bordercolor=PALETTE["border"],
                    font_size=9, itemsizing="constant"),
        margin=dict(l=10, r=10, t=40, b=10),
    )
    st.plotly_chart(fig_scatter, use_container_width=True)


# ── Timeline ──────────────────────────────────────────────────────────────────
tdf = fdf.dropna(subset=["published"]).copy()
if not tdf.empty:
    tdf["hour"] = tdf["published"].dt.floor("h")
    timeline = (
        tdf.groupby(["hour", "sentiment"]).size()
        .reset_index(name="count")
    )

    fig_time = go.Figure()
    for sent, color in [("bullish", PALETTE["bullish"]),
                         ("bearish", PALETTE["bearish"]),
                         ("neutral", PALETTE["neutral"])]:
        sub = timeline[timeline["sentiment"] == sent]
        if not sub.empty:
            fig_time.add_trace(go.Scatter(
                x=sub["hour"], y=sub["count"],
                mode="lines+markers", name=sent.capitalize(),
                line=dict(color=color, width=2),
                fill="tozeroy", fillcolor=color.replace(")", ",0.15)").replace("rgb", "rgba"),
                marker=dict(size=4),
                hovertemplate=f"<b>{sent.capitalize()}</b><br>%{{x}}<br>%{{y}} articles<extra></extra>",
            ))

    fig_time.update_layout(
        title="📰 News Volume by Sentiment Over Time",
        paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
        font_color=PALETTE["text"], height=260,
        xaxis=dict(title="", gridcolor=PALETTE["border"]),
        yaxis=dict(title="Articles", gridcolor=PALETTE["border"]),
        legend=dict(bgcolor=PALETTE["panel"], bordercolor=PALETTE["border"]),
        margin=dict(l=10, r=10, t=40, b=10),
        hovermode="x unified",
    )
    st.plotly_chart(fig_time, use_container_width=True)


# ── Sector heatmap ────────────────────────────────────────────────────────────
st.markdown("### 🌡️ Sector Signal Heatmap")
heat_df = (
    fdf.groupby("primary_sector").agg(
        avg_sentiment=("sentiment_score", "mean"),
        avg_impact=("predicted_price_impact_pct", "mean"),
        avg_confidence=("confidence", "mean"),
        bullish_ratio=("sentiment", lambda x: (x == "bullish").mean()),
        article_count=("title", "count"),
    ).reset_index()
)

heat_matrix = heat_df.set_index("primary_sector")[
    ["avg_sentiment", "avg_impact", "avg_confidence", "bullish_ratio"]
].rename(columns={
    "avg_sentiment": "Sentiment Score",
    "avg_impact": "Price Impact %",
    "avg_confidence": "Confidence",
    "bullish_ratio": "Bullish Ratio",
})

fig_heat = go.Figure(go.Heatmap(
    z=heat_matrix.values,
    x=heat_matrix.columns.tolist(),
    y=heat_matrix.index.tolist(),
    colorscale=[[0, PALETTE["bearish"]], [0.5, PALETTE["neutral"]], [1, PALETTE["bullish"]]],
    zmid=0,
    text=[[f"{v:.2f}" for v in row] for row in heat_matrix.values],
    texttemplate="%{text}",
    textfont={"size": 10, "color": "#ffffff"},
    hovertemplate="<b>%{y}</b><br>%{x}: %{z:.3f}<extra></extra>",
    colorbar=dict(
        tickfont=dict(color=PALETTE["text"]),
        outlinecolor=PALETTE["border"],
    ),
))
fig_heat.update_layout(
    paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
    font_color=PALETTE["text"], height=400,
    xaxis=dict(side="top"),
    margin=dict(l=10, r=10, t=20, b=10),
)
st.plotly_chart(fig_heat, use_container_width=True)


# ── Top movers lollipop ───────────────────────────────────────────────────────
st.markdown("### 🔍 Top News Drivers by Signal Strength")
top_n = fdf.copy()
top_n["abs_impact"] = top_n["predicted_price_impact_pct"].abs()
top_n = top_n.nlargest(12, "abs_impact")

fig_lollipop = go.Figure()
for _, row in top_n.iterrows():
    col = PALETTE["bullish"] if row["predicted_price_impact_pct"] >= 0 else PALETTE["bearish"]
    fig_lollipop.add_trace(go.Scatter(
        x=[0, row["predicted_price_impact_pct"]],
        y=[row["title"][:55], row["title"][:55]],
        mode="lines",
        line=dict(color=col, width=2),
        showlegend=False,
        hoverinfo="skip",
    ))
    fig_lollipop.add_trace(go.Scatter(
        x=[row["predicted_price_impact_pct"]],
        y=[row["title"][:55]],
        mode="markers",
        marker=dict(color=col, size=10, symbol="circle"),
        showlegend=False,
        hovertemplate=(
            f"<b>{row['title'][:60]}</b><br>"
            f"Source: {row['source']}<br>"
            f"Sector: {row['primary_sector']}<br>"
            f"Impact: {row['predicted_price_impact_pct']:+.2f}%<extra></extra>"
        ),
    ))

fig_lollipop.add_vline(x=0, line_color=PALETTE["border"], line_width=1)
fig_lollipop.update_layout(
    paper_bgcolor=PALETTE["bg"], plot_bgcolor=PALETTE["panel"],
    font_color=PALETTE["text"], height=420,
    xaxis=dict(title="Predicted Price Impact (%)", gridcolor=PALETTE["border"],
               zeroline=True, zerolinecolor=PALETTE["border"]),
    yaxis=dict(gridcolor=PALETTE["border"], tickfont=dict(size=9)),
    margin=dict(l=10, r=10, t=20, b=10),
)
st.plotly_chart(fig_lollipop, use_container_width=True)


# ── Article table ─────────────────────────────────────────────────────────────
st.markdown("### 📋 Article Feed")

table_cols = ["title", "source", "primary_sector", "sentiment",
              "sentiment_score", "predicted_price_impact_pct", "confidence"]
available = [c for c in table_cols if c in fdf.columns]
table_df = fdf[available].copy().sort_values(
    "predicted_price_impact_pct", key=abs, ascending=False
).reset_index(drop=True)

# Rename for display
table_df = table_df.rename(columns={
    "primary_sector": "Sector",
    "sentiment_score": "Score",
    "predicted_price_impact_pct": "Impact %",
    "confidence": "Conf",
})

def _color_sentiment(val):
    colors = {"bullish": "color: #3fb950", "bearish": "color: #f85149", "neutral": "color: #8b949e"}
    return colors.get(val, "")

def _color_impact(val):
    try:
        v = float(val)
        return "color: #3fb950" if v > 0 else "color: #f85149" if v < 0 else ""
    except Exception:
        return ""

styled = table_df.style\
    .applymap(_color_sentiment, subset=["sentiment"] if "sentiment" in table_df.columns else [])\
    .applymap(_color_impact, subset=["Impact %"] if "Impact %" in table_df.columns else [])\
    .format({"Score": "{:+.3f}", "Impact %": "{:+.2f}%", "Conf": "{:.0%}"}, na_rep="—")\
    .set_properties(**{
        "background-color": "#161b22",
        "color": "#e6edf3",
        "border-color": "#30363d",
        "font-size": "0.82rem",
    })

st.dataframe(styled, use_container_width=True, height=400)

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown(
    "<div style='text-align:center;color:#8b949e;font-size:0.8rem;'>"
    "⚡ Semantic Stock Analyzer · Sources: Reuters, Bloomberg, CNBC, MarketWatch, Yahoo Finance, Seeking Alpha, FT · "
    "ML: AdaBoost + GBM + PyTorch NN · Sentiment: Gemini 1.5 Flash / Lexicon fallback"
    "</div>",
    unsafe_allow_html=True,
)
