# ⚡ Semantic Stock Analyzer

A full-stack financial intelligence tool that scrapes live financial news, runs AI-powered sentiment analysis, and predicts sector-level price impact signals — all visualized in a dark-mode Streamlit dashboard.

## 🚀 Quick Start

### Streamlit Dashboard (recommended)
```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu
streamlit run app.py
```
Open **http://localhost:8501** → click **🧪 Demo** or **▶ Run Live**.

### CLI (outputs .png + .csv)
```bash
python main.py --demo          # synthetic data, no internet needed
python main.py                 # real live news
GEMINI_API_KEY=your_key python main.py   # + LLM sentiment
```

### Docker
```bash
docker compose up --build
# Open http://localhost:8501
```

## 📁 Structure
```
stock_analyzer/
├── app.py                 # ⭐ Streamlit interactive dashboard
├── main.py                # CLI orchestrator
├── news_scraper.py        # RSS + HTML scraper (8 sources)
├── sector_mapper.py       # S&P 500 GICS sector mapper
├── sentiment_analyzer.py  # Gemini LLM + lexicon fallback
├── ml_models.py           # AdaBoost + GBM + PyTorch ensemble
├── dashboard.py           # Static matplotlib dashboard
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
└── .streamlit/config.toml
```

## 🧠 Pipeline
```
Live News → Sector Mapping → Sentiment AI → ML Ensemble → Dashboard
```
1. Scrapes Reuters, Bloomberg, CNBC, MarketWatch, Yahoo Finance, Seeking Alpha, FT
2. Maps to S&P 500 GICS sectors via keyword matching
3. Gemini 1.5 Flash sentiment (falls back to financial lexicon — no key needed)
4. Ensemble prediction: AdaBoost + Gradient Boosting + PyTorch NN
5. Interactive Streamlit dashboard with Plotly charts

## 🔑 Gemini API Key (Optional, Free)
Get one at https://aistudio.google.com — set as `GEMINI_API_KEY` env var or enter in sidebar.

## ⚙️ CLI Options
```
--gemini-key KEY    API key
--max-articles N    Articles to fetch (default: 80)
--days-back N       History window in days (default: 2)
--full-text         Fetch full article bodies
--retrain           Force retrain ML models
--use-cached        Skip scraping, use cached data
--demo              Synthetic demo mode
```

## 🛠 Tech Stack
Streamlit · Plotly · scikit-learn · PyTorch · BeautifulSoup4 · feedparser · Google Gemini API

## 📝 License
MIT
