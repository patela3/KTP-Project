"""
app.py  —  Signal Desk  |  Semantic Stock Analyzer
Streamlit dashboard with terminal-finance aesthetic.

Run:
    streamlit run app.py
"""

import os
import sys
import threading
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from datetime import datetime, timedelta

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Signal Desk",
    page_icon="▲",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Design tokens ──────────────────────────────────────────────────────────────
BG       = "#07080a"
BG2      = "#0d0f13"
BG3      = "#12151b"
BORDER   = "#1c2030"
BORDER2  = "#252d3d"
TEXT     = "#dce6f5"
MUTED    = "#2a3547"
MUTED2   = "#5c6e8a"
GREEN    = "#00d97e"
GREEN2   = "#008f52"
GREEN_BG = "#001a10"
RED      = "#ff3d55"
RED2     = "#a82538"
RED_BG   = "#1a0008"
BLUE     = "#3d8ef0"
AMBER    = "#f0a030"

PALETTE = {
    "bullish": GREEN, "bearish": RED, "neutral": MUTED2,
    "accent": BLUE, "bg": BG, "panel": BG3,
    "border": BORDER, "text": TEXT,
}

SECTOR_COLORS = {
    "Information Technology": "#3d8ef0",
    "Health Care":             "#00d97e",
    "Financials":              "#f0a030",
    "Consumer Discretionary":  "#c46aff",
    "Communication Services":  "#00bfdb",
    "Industrials":             "#6eb5ff",
    "Consumer Staples":        "#4ddb97",
    "Energy":                  "#ff6b3d",
    "Utilities":               "#ffcc44",
    "Real Estate":             "#aa88ff",
    "Materials":               "#44ddaa",
    "General Market":          "#5c6e8a",
}

MONO = "IBM Plex Mono, Courier New, monospace"
SANS = "DM Sans, system-ui, sans-serif"

# ── Global CSS ─────────────────────────────────────────────────────────────────
st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=DM+Sans:wght@300;400;500;600&display=swap');

*, *::before, *::after {{ box-sizing: border-box; }}
html, body, .stApp {{ background-color: {BG} !important; color: {TEXT}; font-family: {SANS}; }}
.block-container {{ padding: 1.2rem 1.6rem 2rem !important; max-width: 100% !important; }}

#MainMenu, footer, header {{ visibility: hidden; }}
[data-testid="stDecoration"] {{ display: none; }}
.stDeployButton {{ display: none; }}

[data-testid="stSidebar"] {{
    background: {BG} !important;
    border-right: 1px solid {BORDER} !important;
}}
[data-testid="stSidebar"] * {{ color: {TEXT} !important; }}
[data-testid="stSidebar"] .stSlider label,
[data-testid="stSidebar"] .stTextInput label {{
    font-family: {MONO}; font-size: 0.65rem !important;
    letter-spacing: 0.12em; text-transform: uppercase; color: {MUTED2} !important;
}}
[data-testid="stSidebar"] [data-baseweb="input"] input {{
    background: {BG3} !important; border: 1px solid {BORDER2} !important;
    border-radius: 4px !important; color: {MUTED2} !important;
    font-family: {MONO} !important; font-size: 0.7rem !important;
}}
[data-testid="stSidebar"] [data-baseweb="input"] input:focus {{
    border-color: {BLUE} !important; color: {TEXT} !important;
}}
[data-testid="stSidebar"] .stButton button,
.stButton button {{
    background: transparent !important; border: 1px solid {BORDER2} !important;
    border-radius: 4px !important; color: {MUTED2} !important;
    font-family: {MONO} !important; font-size: 0.7rem !important;
    letter-spacing: 0.05em; transition: all 0.15s !important;
}}
[data-testid="stSidebar"] .stButton button:hover,
.stButton button:hover {{
    border-color: {BLUE} !important; color: {BLUE} !important;
    background: rgba(61,142,240,0.06) !important;
}}

[data-testid="metric-container"] {{
    background: {BG3} !important; border: 1px solid {BORDER} !important;
    border-radius: 6px !important; padding: 14px 16px 12px !important;
}}
[data-testid="metric-container"] label {{
    font-family: {MONO} !important; font-size: 0.6rem !important;
    letter-spacing: 0.14em; text-transform: uppercase; color: {MUTED2} !important;
}}
[data-testid="metric-container"] [data-testid="stMetricValue"] {{
    font-family: {MONO} !important; font-size: 1.5rem !important;
    font-weight: 600 !important; color: {TEXT} !important; letter-spacing: -0.02em;
}}
[data-testid="metric-container"] [data-testid="stMetricDelta"] {{
    font-family: {MONO} !important; font-size: 0.68rem !important;
}}

[data-baseweb="tag"] {{
    background: {BG} !important; border: 1px solid {BORDER2} !important; border-radius: 3px !important;
}}
[data-baseweb="tag"] span {{ color: {MUTED2} !important; font-family: {MONO}; font-size: 0.68rem; }}

[data-testid="stDownloadButton"] button {{
    background: transparent !important; border: 1px solid {GREEN2} !important;
    border-radius: 4px !important; color: {GREEN} !important;
    font-family: {MONO} !important; font-size: 0.7rem !important;
}}
[data-testid="stDownloadButton"] button:hover {{
    background: {GREEN_BG} !important;
}}

[data-testid="stExpander"] {{
    background: {BG3} !important; border: 1px solid {BORDER} !important; border-radius: 6px !important;
}}
[data-testid="stExpander"] summary {{
    font-family: {MONO} !important; font-size: 0.68rem !important;
    color: {MUTED2} !important; letter-spacing: 0.08em;
}}

hr {{ border-color: {BORDER} !important; margin: 0.8rem 0 !important; }}

.sig-logo {{
    font-family: {MONO}; font-weight: 600; font-size: 1rem;
    letter-spacing: 0.14em; color: {TEXT};
}}
.sig-logo em {{ color: {MUTED}; font-style: normal; }}
.sig-sub {{ font-family: {MONO}; font-size: 0.65rem; color: {MUTED2}; letter-spacing: 0.06em; }}

.status-pill {{
    display: inline-flex; align-items: center; gap: 5px;
    font-family: {MONO}; font-size: 0.62rem; letter-spacing: 0.1em;
    padding: 2px 9px; border-radius: 3px;
}}
.pill-live {{ background: {GREEN_BG}; color: {GREEN}; border: 1px solid {GREEN2}; }}
.pill-demo {{ background: rgba(240,160,48,.08); color: {AMBER}; border: 1px solid rgba(240,160,48,.35); }}
.pill-dot {{ width: 5px; height: 5px; border-radius: 50%; background: currentColor; animation: blink 2s infinite; }}
@keyframes blink {{ 0%,100% {{ opacity:1 }} 50% {{ opacity:.2 }} }}

.section-label {{
    font-family: {MONO}; font-size: 0.6rem; letter-spacing: 0.16em;
    text-transform: uppercase; color: {MUTED2};
    border-left: 2px solid {BLUE}; padding-left: 8px;
    margin: 16px 0 10px;
}}

.tag {{ display: inline-block; padding: 1px 7px; border-radius: 3px; font-family: {MONO}; font-size: 0.6rem; letter-spacing: 0.05em; }}
.tag-green {{ background: {GREEN_BG}; color: {GREEN}; border: 1px solid {GREEN2}; }}
.tag-red   {{ background: {RED_BG}; color: {RED}; border: 1px solid {RED2}; }}
.tag-blue  {{ background: rgba(61,142,240,.08); color: {BLUE}; border: 1px solid rgba(61,142,240,.3); }}
.tag-muted {{ background: {BG}; color: {MUTED2}; border: 1px solid {BORDER2}; }}

.art-feed {{ background: {BG3}; border: 1px solid {BORDER}; border-radius: 6px; overflow: hidden; }}
.art-row {{
    display: grid; grid-template-columns: 5px 1fr auto;
    gap: 12px; align-items: start;
    padding: 10px 14px; border-bottom: 1px solid {BORDER};
    transition: background .1s;
}}
.art-row:last-child {{ border-bottom: none; }}
.art-row:hover {{ background: {BG}; }}
.art-dot {{ width: 5px; height: 5px; border-radius: 50%; margin-top: 5px; flex-shrink: 0; }}
.art-title {{ font-size: 0.8rem; color: {TEXT}; line-height: 1.5; }}
.art-meta  {{ font-family: {MONO}; font-size: 0.6rem; color: {MUTED2}; margin-top: 3px; }}
.art-impact {{ font-family: {MONO}; font-size: 0.76rem; font-weight: 500; white-space: nowrap; margin-top: 1px; }}

.feature-card {{
    background: {BG3}; border: 1px solid {BORDER}; border-radius: 6px; padding: 20px; height: 100%;
}}
.feature-card h4 {{
    font-family: {MONO}; font-size: 0.68rem; letter-spacing: 0.1em;
    text-transform: uppercase; color: {MUTED2}; margin-bottom: 10px;
}}
.feature-card p {{ font-size: 0.8rem; color: {MUTED2}; line-height: 1.65; }}
</style>
""", unsafe_allow_html=True)


# ── Chart helpers ──────────────────────────────────────────────────────────────
def _layout(**kw) -> dict:
    base = dict(
        paper_bgcolor=BG, plot_bgcolor=BG3,
        font=dict(family=MONO, color=MUTED2, size=10),
        margin=dict(l=8, r=8, t=36, b=8),
        title_font=dict(family=MONO, size=10, color=MUTED2),
        title_x=0, title_pad=dict(l=2),
        xaxis=dict(gridcolor=BORDER, gridwidth=1, zeroline=False, showline=False,
                   tickfont=dict(size=9, family=MONO, color=MUTED2),
                   title_font=dict(size=9, family=MONO, color=MUTED2)),
        yaxis=dict(gridcolor=BORDER, gridwidth=1, zeroline=False, showline=False,
                   tickfont=dict(size=9, family=MONO, color=MUTED2),
                   title_font=dict(size=9, family=MONO, color=MUTED2)),
        legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor=BORDER,
                    font=dict(family=MONO, size=9, color=MUTED2), itemsizing="constant"),
        hoverlabel=dict(bgcolor=BG3, bordercolor=BORDER,
                        font=dict(family=MONO, size=10, color=TEXT)),
    )
    base.update(kw)
    return base

def _chart(fig):
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

def _section(text: str):
    st.markdown(f'<div class="section-label">{text}</div>', unsafe_allow_html=True)

def _rule():
    st.markdown(f'<div style="height:1px;background:{BORDER};margin:8px 0 14px"></div>', unsafe_allow_html=True)


# ── Session state ──────────────────────────────────────────────────────────────
for _k, _v in {"df": None, "last_run": None, "running": False,
                "run_log": [], "demo_mode": False}.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v


# ── Demo data ──────────────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def _demo(seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n = 150
    sectors = list(SECTOR_COLORS.keys())
    sentiments = ["bullish", "neutral", "bearish"]
    sources = ["Reuters", "Bloomberg", "CNBC", "MarketWatch",
               "Yahoo Finance", "Seeking Alpha", "Financial Times"]
    magnitudes = ["high", "medium", "low"]
    titles = [
        "NVIDIA forecasts record AI chip sales amid surging demand",
        "Fed signals rate pause as inflation cools further",
        "Energy stocks surge after OPEC+ extends production cuts",
        "JPMorgan beats Q3 earnings, raises full-year guidance",
        "Tesla delivers record EVs but faces margin compression",
        "Healthcare sector navigates regulatory headwinds",
        "Retail sales beat expectations, consumer resilience intact",
        "Industrial output slows as global trade tensions mount",
        "Utility stocks attractive as bond yields stabilize",
        "Semiconductor shortage eases, chip stocks rally broadly",
        "Amazon Web Services revenue accelerates on AI workloads",
        "Oil prices retreat on weaker-than-expected China data",
        "Biotech index surges after FDA approves key drug",
        "Microsoft Azure growth beats cloud rivals for fourth quarter",
        "Apple unveils next-gen iPhone with AI integration suite",
        "Goldman Sachs upgrades S&P 500 target on earnings momentum",
        "EV battery cost declines accelerate industry adoption",
        "Copper prices hit multi-year high on green energy demand",
    ] * 9
    sent_arr = rng.choice(sentiments, n, p=[0.42, 0.28, 0.30])
    scores = np.where(sent_arr == "bullish",  rng.uniform(0.15, 0.95, n),
             np.where(sent_arr == "bearish", -rng.uniform(0.15, 0.95, n),
                                              rng.uniform(-0.12, 0.12, n)))
    sector_arr = rng.choice(sectors, n)
    impact = scores * rng.uniform(1.2, 3.5, n)
    return pd.DataFrame({
        "article_id":                [f"demo_{i:04d}" for i in range(n)],
        "title":                     rng.choice(titles, n),
        "source":                    rng.choice(sources, n),
        "primary_sector":            sector_arr,
        "sentiment":                 sent_arr,
        "sentiment_score":           scores.round(4),
        "confidence":                rng.uniform(0.45, 0.95, n).round(3),
        "impact_magnitude":          rng.choice(magnitudes, n, p=[0.22, 0.48, 0.30]),
        "predicted_price_impact_pct": impact.round(3),
        "sector_relevance":          rng.uniform(0.3, 1.0, n).round(3),
        "key_drivers":               ["AI demand | cloud | earnings"] * n,
        "analysis_method":           rng.choice(["gemini", "lexicon"], n, p=[0.35, 0.65]),
        "published":                 [datetime.now() - timedelta(hours=int(h))
                                      for h in rng.integers(0, 48, n)],
        "url":                       [f"https://example.com/article/{i}" for i in range(n)],
    })


# ── Pipeline ───────────────────────────────────────────────────────────────────
def _run_live(gemini_key: str, max_articles: int, days_back: int):
    st.session_state["running"] = True
    st.session_state["run_log"] = []

    def _work():
        try:
            sys.path.insert(0, os.path.dirname(__file__))
            from news_scraper import FinancialNewsScraper
            from sector_mapper import SectorMapper
            from sentiment_analyzer import SentimentAnalyzer
            from ml_models import EnsemblePredictor
            log = st.session_state["run_log"]
            log.append("↳ fetching news...")
            scraper = FinancialNewsScraper(max_articles_per_source=max_articles // 8,
                                           days_back=days_back)
            df = scraper.fetch_all(include_full_text=False)
            log.append(f"↳ {len(df)} articles fetched")
            if df.empty:
                log.append("✗ no articles — check connection or use Demo")
                st.session_state["running"] = False
                return
            log.append("↳ mapping sectors...")
            df = SectorMapper().map_dataframe(df)
            log.append("↳ sentiment analysis...")
            df = SentimentAnalyzer(gemini_api_key=gemini_key).analyze_dataframe(df)
            log.append("↳ ml predictions...")
            pred = EnsemblePredictor()
            if not pred.load():
                pred.train()
            df = pred.predict_dataframe(df)
            st.session_state.update({"df": df, "last_run": datetime.now(), "demo_mode": False})
            log.append("✓ complete")
        except Exception as e:
            st.session_state["run_log"].append(f"✗ {e}")
        finally:
            st.session_state["running"] = False

    threading.Thread(target=_work, daemon=True).start()


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(
        f'<div style="padding:4px 0 16px">'
        f'<div class="sig-logo">SIGNAL<em>_</em>DESK</div>'
        f'<div class="sig-sub" style="margin-top:3px">semantic stock intelligence</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
    _rule()

    st.markdown(f'<div style="font-family:{MONO};font-size:0.6rem;letter-spacing:.14em;'
                f'text-transform:uppercase;color:{MUTED2};margin-bottom:8px">Pipeline</div>',
                unsafe_allow_html=True)

    gemini_key   = st.text_input("Gemini API Key", type="password",
                                  value=os.getenv("GEMINI_API_KEY", ""),
                                  help="Optional — free key at aistudio.google.com")
    max_articles = st.slider("Max Articles", 20, 200, 80, step=20)
    days_back    = st.slider("Days Back", 1, 7, 2)

    st.markdown("<br>", unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        live_btn = st.button("▶ Run Live", use_container_width=True,
                             disabled=st.session_state["running"])
    with c2:
        demo_btn = st.button("◎ Demo", use_container_width=True,
                             disabled=st.session_state["running"])

    if live_btn:
        _run_live(gemini_key, max_articles, days_back)
    if demo_btn:
        st.session_state.update({
            "df": _demo(), "last_run": datetime.now(),
            "demo_mode": True, "run_log": ["✓ demo — 150 synthetic articles"],
        })

    if st.session_state["running"]:
        st.markdown(f'<div style="font-family:{MONO};font-size:0.65rem;color:{AMBER};margin-top:10px">● running...</div>',
                    unsafe_allow_html=True)
    for msg in st.session_state["run_log"]:
        st.markdown(f'<div style="font-family:{MONO};font-size:0.62rem;color:{MUTED2}">{msg}</div>',
                    unsafe_allow_html=True)

    _rule()
    st.markdown(f'<div style="font-family:{MONO};font-size:0.6rem;letter-spacing:.14em;'
                f'text-transform:uppercase;color:{MUTED2};margin-bottom:8px">Export</div>',
                unsafe_allow_html=True)
    if st.session_state["df"] is not None:
        csv = st.session_state["df"].to_csv(index=False).encode()
        st.download_button("⬇ Download CSV", csv, "signal_desk.csv", "text/csv",
                           use_container_width=True)
    else:
        st.markdown(f'<div style="font-family:{MONO};font-size:0.62rem;color:{MUTED}">no data</div>',
                    unsafe_allow_html=True)

    _rule()
    st.markdown(f'<div style="font-family:{MONO};font-size:0.58rem;color:{MUTED};line-height:1.9">'
                f'Streamlit · Plotly · scikit-learn<br>PyTorch · Gemini 1.5 Flash<br>'
                f'BeautifulSoup4 · feedparser</div>', unsafe_allow_html=True)


# ── Header bar ─────────────────────────────────────────────────────────────────
hc1, hc2 = st.columns([3, 1])
with hc1:
    st.markdown(
        f'<div style="display:flex;align-items:baseline;gap:10px">'
        f'<span style="font-family:{MONO};font-weight:600;font-size:1.05rem;'
        f'letter-spacing:.12em;color:{TEXT}">SIGNAL<span style="color:{MUTED}">_</span>DESK</span>'
        f'<span style="font-family:{MONO};font-size:0.62rem;color:{MUTED2}">S&P 500 sector intelligence</span>'
        f'</div>',
        unsafe_allow_html=True,
    )
with hc2:
    if st.session_state["last_run"]:
        mode  = st.session_state.get("demo_mode")
        pcls  = "pill-demo" if mode else "pill-live"
        plbl  = "DEMO" if mode else "LIVE"
        ts    = st.session_state["last_run"].strftime("%H:%M:%S")
        st.markdown(
            f'<div style="display:flex;align-items:center;justify-content:flex-end;gap:8px;padding-top:4px">'
            f'<span class="status-pill {pcls}"><span class="pill-dot"></span>{plbl}</span>'
            f'<span style="font-family:{MONO};font-size:0.62rem;color:{MUTED2}">{ts}</span>'
            f'</div>',
            unsafe_allow_html=True,
        )
_rule()


# ── No-data splash ─────────────────────────────────────────────────────────────
if st.session_state["df"] is None:
    st.markdown(
        f'<div style="font-family:{MONO};font-size:0.72rem;color:{MUTED2};margin-bottom:20px">'
        f'Hit <span style="color:{BLUE}">▶ Run Live</span> to scrape today\'s financial news, '
        f'or <span style="color:{AMBER}">◎ Demo</span> to preview with synthetic data.</div>',
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    for col, title, body in zip(
        [c1, c2, c3],
        ["News Scraping", "AI Sentiment", "ML Ensemble"],
        [
            "Pulls from Reuters, Bloomberg, CNBC, MarketWatch, Yahoo Finance, Seeking Alpha & FT via RSS + HTML.",
            "Google Gemini 1.5 Flash for deep equity research. Falls back to financial lexicon — no key needed.",
            "AdaBoost + Gradient Boosting + PyTorch Neural Net predict sector-level price impact signals.",
        ],
    ):
        with col:
            st.markdown(f'<div class="feature-card"><h4>{title}</h4><p>{body}</p></div>',
                        unsafe_allow_html=True)
    st.stop()


# ── Data prep ──────────────────────────────────────────────────────────────────
df = st.session_state["df"].copy()
for col, default in [
    ("sentiment", "neutral"), ("sentiment_score", 0.0), ("confidence", 0.5),
    ("predicted_price_impact_pct", 0.0), ("primary_sector", "General Market"),
    ("source", "Unknown"), ("impact_magnitude", "medium"),
]:
    if col not in df.columns:
        df[col] = default
df["published"] = pd.to_datetime(df.get("published", pd.NaT), errors="coerce")


# ── Filters ────────────────────────────────────────────────────────────────────
_section("Filters")
fc1, fc2, fc3, fc4 = st.columns([2, 2, 3, 1])
with fc1:
    all_sec  = sorted(df["primary_sector"].dropna().unique().tolist())
    sel_sec  = st.multiselect("Sectors", all_sec, default=all_sec,
                               label_visibility="collapsed", placeholder="Sectors")
with fc2:
    sel_sent = st.multiselect("Sentiment", ["bullish", "neutral", "bearish"],
                               default=["bullish", "neutral", "bearish"],
                               label_visibility="collapsed", placeholder="Sentiment")
with fc3:
    all_src  = sorted(df["source"].dropna().unique().tolist())
    sel_src  = st.multiselect("Sources", all_src, default=all_src,
                               label_visibility="collapsed", placeholder="Sources")
with fc4:
    if st.button("↺ Reset", use_container_width=True):
        sel_sec  = all_sec
        sel_sent = ["bullish", "neutral", "bearish"]
        sel_src  = all_src

fdf = df[
    df["primary_sector"].isin(sel_sec) &
    df["sentiment"].isin(sel_sent) &
    df["source"].isin(sel_src)
].copy()

if fdf.empty:
    st.markdown(f'<div style="font-family:{MONO};font-size:0.72rem;color:{MUTED2};padding:20px 0">'
                f'no articles match filters</div>', unsafe_allow_html=True)
    st.stop()


# ── KPIs ───────────────────────────────────────────────────────────────────────
_rule()
n_tot  = len(fdf)
n_bull = (fdf["sentiment"] == "bullish").sum()
n_bear = (fdf["sentiment"] == "bearish").sum()
avg_i  = fdf["predicted_price_impact_pct"].mean()
avg_c  = fdf["confidence"].mean()
top_s  = fdf.groupby("primary_sector")["predicted_price_impact_pct"].mean().abs().idxmax()
bp, rp = n_bull / n_tot if n_tot else 0, n_bear / n_tot if n_tot else 0

k1, k2, k3, k4, k5, k6 = st.columns(6)
k1.metric("Articles",       n_tot,              f"from {fdf['source'].nunique()} sources")
k2.metric("Bullish",        n_bull,             f"{bp:.0%}")
k3.metric("Bearish",        n_bear,             f"{rp:.0%}", delta_color="inverse")
k4.metric("Avg Impact",     f"{avg_i:+.2f}%",   "predicted")
k5.metric("Avg Confidence", f"{avg_c:.0%}",     "ensemble")
k6.metric("Top Sector",     top_s[:15] + ("…" if len(top_s) > 15 else ""), "")
_rule()


# ── Row 1: Sector impact bar + Sentiment donut ─────────────────────────────────
_section("Sector Signals")
r1a, r1b = st.columns([3, 2])

with r1a:
    ss = (
        fdf.groupby("primary_sector")
        .agg(avg_impact=("predicted_price_impact_pct", "mean"),
             avg_conf=("confidence", "mean"), count=("title", "count"))
        .reset_index().sort_values("avg_impact")
    )
    ss["color"] = ss["avg_impact"].apply(lambda x: GREEN if x >= 0 else RED)

    fig = go.Figure(go.Bar(
        x=ss["avg_impact"], y=ss["primary_sector"], orientation="h",
        marker=dict(color=ss["color"], opacity=0.85, line=dict(width=0)),
        text=ss["avg_impact"].apply(lambda x: f"{x:+.2f}%"),
        textposition="outside", textfont=dict(family=MONO, size=9, color=TEXT),
        error_x=dict(type="data", array=[(1-c)*1.1 for c in ss["avg_conf"]],
                     color=MUTED, thickness=1, width=3),
        hovertemplate="<b>%{y}</b><br>Impact: %{x:+.2f}%<br>n=%{customdata[0]}<br>conf=%{customdata[1]:.0%}<extra></extra>",
        customdata=ss[["count", "avg_conf"]].values,
    ))
    fig.update_layout(**_layout(
        title="predicted price impact by sector", height=380,
        xaxis=dict(gridcolor=BORDER, zeroline=True, zerolinecolor=BORDER2, zerolinewidth=1,
                   ticksuffix="%", tickfont=dict(size=9, family=MONO, color=MUTED2)),
        yaxis=dict(gridcolor="rgba(0,0,0,0)", tickfont=dict(size=9, family=MONO, color=MUTED2)),
        margin=dict(l=8, r=58, t=36, b=8), showlegend=False,
    ))
    _chart(fig)

with r1b:
    sc = fdf["sentiment"].value_counts().reset_index()
    sc.columns = ["sentiment", "count"]
    cmap = {"bullish": GREEN, "bearish": RED, "neutral": MUTED2}

    fig = go.Figure(go.Pie(
        labels=sc["sentiment"], values=sc["count"], hole=0.65,
        marker=dict(colors=[cmap.get(s, MUTED2) for s in sc["sentiment"]],
                    line=dict(color=BG, width=3)),
        textinfo="label+percent", textfont=dict(family=MONO, size=9, color=TEXT),
        hovertemplate="<b>%{label}</b><br>%{value} articles — %{percent}<extra></extra>",
        rotation=90,
    ))
    fig.add_annotation(text=f"<b>{n_tot}</b>", x=0.5, y=0.55, showarrow=False,
                       font=dict(family=MONO, size=22, color=TEXT))
    fig.add_annotation(text="articles", x=0.5, y=0.38, showarrow=False,
                       font=dict(family=MONO, size=9, color=MUTED2))
    fig.update_layout(**_layout(
        title="sentiment distribution", height=380, showlegend=True,
        legend=dict(orientation="h", y=-0.06, font=dict(family=MONO, size=9, color=MUTED2)),
        margin=dict(l=8, r=8, t=36, b=30),
    ))
    _chart(fig)


# ── Row 2: Source bar + Scatter ────────────────────────────────────────────────
_section("Signal Analysis")
r2a, r2b = st.columns([2, 3])

with r2a:
    src = fdf["source"].value_counts().reset_index()
    src.columns = ["source", "count"]
    fig = go.Figure(go.Bar(
        x=src["count"], y=src["source"], orientation="h",
        marker=dict(color=src["count"], colorscale=[[0, MUTED], [1, BLUE]],
                    showscale=False, line=dict(width=0)),
        text=src["count"], textposition="outside",
        textfont=dict(family=MONO, size=9, color=MUTED2),
        hovertemplate="<b>%{y}</b><br>%{x} articles<extra></extra>",
    ))
    fig.update_layout(**_layout(
        title="articles by source", height=320,
        xaxis=dict(gridcolor=BORDER, tickfont=dict(size=9, family=MONO, color=MUTED2)),
        yaxis=dict(gridcolor="rgba(0,0,0,0)", tickfont=dict(size=9, family=MONO, color=MUTED2)),
        margin=dict(l=8, r=30, t=36, b=8), showlegend=False,
    ))
    _chart(fig)

with r2b:
    sdf = fdf.copy()
    sdf["sz"] = (sdf["confidence"] * 14 + 4).clip(4, 18)
    fig = go.Figure()
    for sector in sdf["primary_sector"].unique():
        sub = sdf[sdf["primary_sector"] == sector]
        fig.add_trace(go.Scatter(
            x=sub["sentiment_score"], y=sub["predicted_price_impact_pct"],
            mode="markers", name=sector,
            marker=dict(color=SECTOR_COLORS.get(sector, MUTED2), size=sub["sz"],
                        opacity=0.72, line=dict(width=0.5, color=BG)),
            hovertemplate="<b>%{customdata[0]}</b><br>sent=%{x:.3f} imp=%{y:+.2f}%<br>conf=%{customdata[1]:.0%}<extra></extra>",
            customdata=sub[["title", "confidence"]].values,
        ))
    try:
        x = sdf["sentiment_score"].fillna(0).values
        y = sdf["predicted_price_impact_pct"].fillna(0).values
        if len(x) > 5:
            z = np.polyfit(x, y, 1)
            p = np.poly1d(z)
            xl = np.linspace(x.min(), x.max(), 100)
            fig.add_trace(go.Scatter(x=xl, y=p(xl), mode="lines",
                                     line=dict(color=BLUE, width=1.5, dash="dot"),
                                     name="trend", showlegend=False))
    except Exception:
        pass
    fig.add_hline(y=0, line_color=BORDER2, line_width=1)
    fig.add_vline(x=0, line_color=BORDER2, line_width=1)
    fig.update_layout(**_layout(
        title="sentiment score vs predicted impact", height=320,
        xaxis=dict(title="sentiment score", gridcolor=BORDER,
                   tickfont=dict(size=9, family=MONO, color=MUTED2),
                   title_font=dict(size=9, family=MONO, color=MUTED2)),
        yaxis=dict(title="impact (%)", gridcolor=BORDER, ticksuffix="%",
                   tickfont=dict(size=9, family=MONO, color=MUTED2),
                   title_font=dict(size=9, family=MONO, color=MUTED2)),
        legend=dict(font=dict(size=8, family=MONO, color=MUTED2), itemsizing="constant"),
        margin=dict(l=8, r=8, t=36, b=8),
    ))
    _chart(fig)


# ── Timeline ───────────────────────────────────────────────────────────────────
_section("Volume Timeline")
tdf = fdf.dropna(subset=["published"]).copy()
if not tdf.empty:
    tdf["hour"] = tdf["published"].dt.floor("h")
    tl = tdf.groupby(["hour", "sentiment"]).size().reset_index(name="count")
    fig = go.Figure()
    for sent, color in [("bullish", GREEN), ("bearish", RED), ("neutral", MUTED2)]:
        sub = tl[tl["sentiment"] == sent]
        if not sub.empty:
            fig.add_trace(go.Scatter(
                x=sub["hour"], y=sub["count"], mode="lines", name=sent,
                line=dict(color=color, width=1.5),
                fill="tozeroy", fillcolor=f"{color}22",
                hovertemplate=f"<b>{sent}</b><br>%{{x}}<br>%{{y}} articles<extra></extra>",
            ))
    fig.update_layout(**_layout(
        title="news volume by sentiment — last 48h", height=200,
        xaxis=dict(gridcolor=BORDER, tickfont=dict(size=8, family=MONO, color=MUTED2)),
        yaxis=dict(gridcolor=BORDER, title="count",
                   tickfont=dict(size=8, family=MONO, color=MUTED2),
                   title_font=dict(size=9, family=MONO, color=MUTED2)),
        margin=dict(l=8, r=8, t=36, b=8), hovermode="x unified",
    ))
    _chart(fig)


# ── Heatmap ────────────────────────────────────────────────────────────────────
_section("Sector Heatmap")
heat = (
    fdf.groupby("primary_sector").agg(
        Sentiment=("sentiment_score", "mean"),
        Impact=("predicted_price_impact_pct", "mean"),
        Confidence=("confidence", "mean"),
        Bullish=("sentiment", lambda x: (x == "bullish").mean()),
    ).reset_index()
)
hm = heat.set_index("primary_sector")[["Sentiment", "Impact", "Confidence", "Bullish"]]
fig = go.Figure(go.Heatmap(
    z=hm.values, x=hm.columns.tolist(), y=hm.index.tolist(),
    colorscale=[[0, RED], [0.5, BG3], [1, GREEN]], zmid=0,
    text=[[f"{v:.2f}" for v in row] for row in hm.values],
    texttemplate="%{text}", textfont=dict(size=9, family=MONO, color=TEXT),
    hovertemplate="<b>%{y}</b><br>%{x}: %{z:.3f}<extra></extra>",
    colorbar=dict(thickness=10, len=0.8,
                  tickfont=dict(family=MONO, size=8, color=MUTED2),
                  outlinecolor=BORDER, outlinewidth=1),
))
fig.update_layout(**_layout(
    title="sector signal heatmap", height=360,
    xaxis=dict(side="top", gridcolor="rgba(0,0,0,0)",
               tickfont=dict(size=9, family=MONO, color=MUTED2)),
    yaxis=dict(gridcolor="rgba(0,0,0,0)", tickfont=dict(size=9, family=MONO, color=MUTED2)),
    margin=dict(l=8, r=60, t=36, b=8),
))
_chart(fig)


# ── Lollipop ───────────────────────────────────────────────────────────────────
_section("Top Signal Drivers")
top12 = fdf.copy()
top12["_abs"] = top12["predicted_price_impact_pct"].abs()
top12 = top12.nlargest(12, "_abs")
fig = go.Figure()
for _, row in top12.iterrows():
    col = GREEN if row["predicted_price_impact_pct"] >= 0 else RED
    lbl = row["title"][:50] + ("…" if len(row["title"]) > 50 else "")
    fig.add_trace(go.Scatter(
        x=[0, row["predicted_price_impact_pct"]], y=[lbl, lbl],
        mode="lines", line=dict(color=col, width=1.5),
        showlegend=False, hoverinfo="skip",
    ))
    fig.add_trace(go.Scatter(
        x=[row["predicted_price_impact_pct"]], y=[lbl], mode="markers",
        marker=dict(color=col, size=8, line=dict(width=1, color=BG)),
        showlegend=False,
        hovertemplate=(
            f"<b>{row['title'][:60]}</b><br>"
            f"src: {row.get('source','?')} · {row['primary_sector']}<br>"
            f"impact: {row['predicted_price_impact_pct']:+.2f}%<extra></extra>"
        ),
    ))
fig.add_vline(x=0, line_color=BORDER2, line_width=1)
fig.update_layout(**_layout(
    title="top articles by signal strength", height=420,
    xaxis=dict(title="predicted impact (%)", ticksuffix="%", gridcolor=BORDER,
               tickfont=dict(size=9, family=MONO, color=MUTED2),
               title_font=dict(size=9, family=MONO, color=MUTED2)),
    yaxis=dict(gridcolor="rgba(0,0,0,0)", tickfont=dict(size=9, family=MONO, color=MUTED2)),
    margin=dict(l=8, r=8, t=36, b=8),
))
_chart(fig)


# ── Article feed ───────────────────────────────────────────────────────────────
_section("Article Feed")
feed = fdf.sort_values("predicted_price_impact_pct", key=abs, ascending=False).head(40)

def _sc(s): return GREEN if s == "bullish" else RED if s == "bearish" else MUTED2

rows = ""
for _, row in feed.iterrows():
    sc2 = _sc(row["sentiment"])
    imp = row["predicted_price_impact_pct"]
    ic  = GREEN if imp >= 0 else RED
    sgn = "+" if imp >= 0 else ""
    method = row.get("analysis_method", "?")
    rows += (
        f'<div class="art-row">'
        f'<div class="art-dot" style="background:{sc2}"></div>'
        f'<div>'
        f'<div class="art-title">{row["title"]}</div>'
        f'<div class="art-meta">{row.get("source","?")} &nbsp;·&nbsp; {row["primary_sector"]}'
        f' &nbsp;·&nbsp; <span style="color:{sc2}">{row["sentiment"]}</span>'
        f' &nbsp;·&nbsp; <span style="color:{MUTED}">{method}</span></div>'
        f'</div>'
        f'<div class="art-impact" style="color:{ic}">{sgn}{imp:.2f}%</div>'
        f'</div>'
    )

st.markdown(f'<div class="art-feed" style="max-height:480px;overflow-y:auto">{rows}</div>',
            unsafe_allow_html=True)


# ── Raw table (collapsed) ──────────────────────────────────────────────────────
with st.expander("raw data table", expanded=False):
    cols = ["title", "source", "primary_sector", "sentiment",
            "sentiment_score", "predicted_price_impact_pct", "confidence"]
    avail = [c for c in cols if c in fdf.columns]
    tbl = (fdf[avail].copy()
           .sort_values("predicted_price_impact_pct", key=abs, ascending=False)
           .reset_index(drop=True)
           .rename(columns={"primary_sector": "Sector", "sentiment_score": "Score",
                             "predicted_price_impact_pct": "Impact %", "confidence": "Conf"}))

    def _css_s(v): return {"bullish": f"color: {GREEN}", "bearish": f"color: {RED}",
                            "neutral": f"color: {MUTED2}"}.get(v, "")
    def _css_i(v):
        try: return f"color: {GREEN}" if float(v) > 0 else f"color: {RED}"
        except: return ""

    styled = (tbl.style
        .applymap(_css_s, subset=["sentiment"] if "sentiment" in tbl.columns else [])
        .applymap(_css_i, subset=["Impact %"] if "Impact %" in tbl.columns else [])
        .format({"Score": "{:+.3f}", "Impact %": "{:+.2f}%", "Conf": "{:.0%}"}, na_rep="—")
        .set_properties(**{"background-color": BG3, "color": TEXT,
                           "border-color": BORDER, "font-size": "0.75rem", "font-family": MONO}))
    st.dataframe(styled, use_container_width=True, height=360)


# ── Footer ─────────────────────────────────────────────────────────────────────
_rule()
st.markdown(
    f'<div style="font-family:{MONO};font-size:0.58rem;color:{MUTED};text-align:center;'
    f'letter-spacing:.06em;padding-bottom:8px">'
    f'SIGNAL_DESK &nbsp;·&nbsp; '
    f'Reuters · Bloomberg · CNBC · MarketWatch · Yahoo Finance · Seeking Alpha · FT '
    f'&nbsp;·&nbsp; AdaBoost + GBM + PyTorch &nbsp;·&nbsp; Gemini 1.5 Flash / Lexicon'
    f'</div>',
    unsafe_allow_html=True,
)
